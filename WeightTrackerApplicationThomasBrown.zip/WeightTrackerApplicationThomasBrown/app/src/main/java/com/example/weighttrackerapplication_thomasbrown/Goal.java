package com.example.weighttrackerapplication_thomasbrown;


import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

//Goal datatable
@Entity(tableName = "goal",
        foreignKeys = @ForeignKey(entity = User.class,
                parentColumns = "username",
                childColumns = "username",
                onDelete = ForeignKey.CASCADE),
        indices = {@Index(value = {"username"}, unique = true)})
public class Goal {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String username;
    private double goal;

    // Constructors
    public Goal() {}

    public Goal(double goal, String username) {;
        this.username = username;
        this.goal = goal;
    }

    // Get
    public int getId() { return id; }

    public String getUsername() { return username; }

    public double getGoal() { return goal; }

    // Set
    public void setId(int id) { this.id = id; }

    public void setUsername(String username) { this.username = username; }

    public void setGoal(double goal) { this.goal = goal; }
}
