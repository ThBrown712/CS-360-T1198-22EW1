package com.example.weighttrackerapplication_thomasbrown;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class UpdateEntry extends AppCompatActivity {

    private TheDatabase weightDb;
    private WeightData weightData;
    private User user;
    private EditText enterDate, enterWeight;
    private Button acceptButton, cancelButton, acceptButton2;
    Date date;
    DateFormat dateFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.update_entry_activity);

            //singleton
            weightDb = TheDatabase.getInstance(getApplicationContext());
            weightData = weightDb.weightD();

            enterDate = (EditText) this.findViewById(R.id.editTextDate);
            enterWeight = (EditText) this.findViewById(R.id.deleteRecord_editTextWeight);
            acceptButton = (Button) this.findViewById(R.id.acceptButton);
            acceptButton2 = (Button) this.findViewById(R.id.acceptButton2);
            cancelButton = (Button) this.findViewById(R.id.cancelButton);

            Intent intent = getIntent();
            user = (User) intent.getSerializableExtra("user");

            //date format
            dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
    }



    //Search for entry on entered date
    public void acceptButtonOnClick(View view) throws ParseException {

            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(acceptButton.getWindowToken(), InputMethodManager.RESULT_UNCHANGED_SHOWN);

            // get date input and parse
            String date_string = enterDate.getText().toString();
            date = dateFormat.parse(date_string);

            // query for entered date
            Weight existingRecord = weightData.getRecordWithDate(user.getUsername(), date);

            // Throw message if date not found
            if (existingRecord == null) {
                Toast.makeText(UpdateEntry.this, "Date not found", Toast.LENGTH_LONG).show();

                return;
            }

            // Show weight text box, change to accept button 2
            Toast.makeText(UpdateEntry.this, "Enter New Weight", Toast.LENGTH_LONG).show();
            acceptButton.setVisibility(View.INVISIBLE);
            acceptButton2.setVisibility(View.VISIBLE);
            enterWeight.setVisibility(View.VISIBLE);
            // lock the date
            enterDate.setFocusable(false);
    }



    //Update entry
    public void acceptButton2OnClick(View view) {
        try {

            // get weight input
            String weight_string = enterWeight.getText().toString();
            // if weight input is not a parsable double
            if (!isParsableDouble(weight_string)) {
                Toast.makeText(UpdateEntry.this, "Error with Entry", Toast.LENGTH_LONG).show();

            }
            // parse input to double
            double weight = Double.parseDouble(weight_string);

            // perform update on database record
            weightData.updateWeight(user.getUsername(), date, weight);

            // end this activity and return to calling activity
            Intent returnableIntent = getIntent();
            setResult(Activity.RESULT_OK, returnableIntent);
            finish();

        }catch (Exception e) {
            Toast.makeText(UpdateEntry.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    public void cancelButtonClick(View view) {
        Intent returnIntent = getIntent();
        setResult(Activity.RESULT_CANCELED, returnIntent);
        finish();
    }


    public static boolean isParsableDouble(String input) {
        try {
            Double.parseDouble(input);
            return true;
        } catch (final NumberFormatException e) {
            return false;
        }
    }
}