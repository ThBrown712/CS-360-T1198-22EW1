package com.example.weighttrackerapplication_thomasbrown;


import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import java.io.Serializable;

//User datatable
@Entity(tableName = "users",
        indices = {@Index(value = {"username"}, unique = true)})
public class User implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String username;

    private String password;

    // Constructors
    public User() {
        username = null;
        password = null;
    }

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Get
    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    // Set
    public void setId(int id) {
        this.id = id;
    }

    public void setUsername(String username) { this.username = username;}

    public void setPassword(String password) {
        this.password = password;
    }

}