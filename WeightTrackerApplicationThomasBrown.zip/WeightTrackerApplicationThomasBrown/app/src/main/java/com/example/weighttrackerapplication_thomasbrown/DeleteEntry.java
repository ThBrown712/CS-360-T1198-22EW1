package com.example.weighttrackerapplication_thomasbrown;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DeleteEntry extends AppCompatActivity {

    private TheDatabase WeightDb;
    private WeightData weightData;
    private User user;
    private EditText enterDate;
    private Button deleteButton, deleteButton2, cancelButton;
    Date date;
    DateFormat dateFormat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);
            setContentView(R.layout.delete_entry_activity);

            // singleton
            WeightDb = TheDatabase.getInstance(getApplicationContext());
            weightData  = WeightDb.weightD();

            enterDate = (EditText) this.findViewById(R.id.editTextDate);
            deleteButton = (Button) this.findViewById(R.id.deleteButton);
            deleteButton2 = (Button) this.findViewById(R.id.deleteButton2);
            cancelButton = (Button) this.findViewById(R.id.cancelButton);


            Intent intent = getIntent();
            user = (User) intent.getSerializableExtra("user");

            // set formatter
            dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
    }



    //searches for record based on date enetered
    public void deleteButtonOnClick(View view) throws ParseException {
            // hide keyboard
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(deleteButton.getWindowToken(), InputMethodManager.RESULT_UNCHANGED_SHOWN);

            // get date input and parse
            String date_string = enterDate.getText().toString();
            date = dateFormat.parse(date_string);

            // query the database for the date
            Weight existingRecord = weightData.getRecordWithDate(user.getUsername(), date);

            // if date not found
            if (existingRecord == null) {
                Toast.makeText(DeleteEntry.this, "Date not found", Toast.LENGTH_LONG).show();
                return;
            }

            deleteButton.setVisibility(View.INVISIBLE);
            deleteButton2.setVisibility(View.VISIBLE);
            // lock the date so user can't change it
            enterDate.setFocusable(false);
        Toast.makeText(DeleteEntry.this, "Entry Found, Confirm Deletion", Toast.LENGTH_LONG).show();

    }



    public void deleteButton2OnClick(View view) {


        List<Weight> weights = weightData
                .getUserWeights(user.getUsername());


        // delete record from database
        weightData.deleteWeight(user.getUsername(), date);

        // Verify record deleted
        boolean onlyRecordDeleted = false;
        if (weights.size() == 0) {
            onlyRecordDeleted = true;
        }

        // end this activity and return to calling activity
        Intent returnableIntent = getIntent();
        returnableIntent.putExtra("onlyRecordDeleted", onlyRecordDeleted);
        setResult(Activity.RESULT_OK, returnableIntent);
        finish();
    }


    public void cancelButtonClick(View view) {
        Intent returnIntent = getIntent();
        setResult(Activity.RESULT_CANCELED, returnIntent);
        finish();
    }
}