package com.example.weighttrackerapplication_thomasbrown;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface userData {

    /**
     * Get list of all users
     */
    @Query("SELECT * FROM users ORDER BY username")
    List<User> getUsers();

    @Insert(onConflict = OnConflictStrategy.ABORT)
    void insertUser(User user);
}