package com.example.weighttrackerapplication_thomasbrown;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

//Creates database
@Database(entities = {User.class, Weight.class, Goal.class}, version = 1)
@TypeConverters({Converter.class})
public abstract class TheDatabase extends RoomDatabase {

    private static final String DATABASE_NAME = "weightTracker.db";

    private static TheDatabase theDatabase;

    // Singleton pattern
    public static TheDatabase getInstance(Context context) {
        if (theDatabase == null) {
            theDatabase = Room.databaseBuilder(context, TheDatabase.class,
                    DATABASE_NAME).allowMainThreadQueries().build();
        }
        return theDatabase;
    }

    public abstract userData userD();
    public abstract WeightData weightD();
    public abstract GoalData goalD();
}