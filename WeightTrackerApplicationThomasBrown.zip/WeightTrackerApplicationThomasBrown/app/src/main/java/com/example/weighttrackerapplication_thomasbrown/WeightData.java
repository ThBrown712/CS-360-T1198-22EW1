package com.example.weighttrackerapplication_thomasbrown;


import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.Date;
import java.util.List;

@Dao
public interface WeightData {


    //Get list of weights from current user
    @Query("SELECT * FROM weights WHERE username = :input ORDER BY date ASC")
    public List<Weight> getUserWeights(String input);

    @Query("SELECT * FROM weights WHERE username = :username AND date = :date LIMIT 1")
    public Weight getRecordWithDate(String username, Date date);


    //Update weight data for user
    @Query("UPDATE weights SET weight = :newWeight WHERE username = :username AND date = :date")
    void updateWeight(String username, Date date, double newWeight);


    //Delete a weight entry
    @Query("DELETE FROM weights WHERE username = :username AND  date = :date")
    void deleteWeight(String username, Date date);

    @Insert(onConflict = OnConflictStrategy.ABORT)
    public void insertWeight(Weight weight);


}
