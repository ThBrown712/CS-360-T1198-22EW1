package com.example.weighttrackerapplication_thomasbrown;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class LoginActivity extends AppCompatActivity {

    private TheDatabase weightDb;
    private userData userD;
    private User user;

    CheckBox newUser;
    Button login, cancel;
    EditText username, password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        cancel = (Button) this.findViewById(R.id.cancel_button);

        // singleton
        weightDb = TheDatabase.getInstance(getApplicationContext());
        userD = weightDb.userD();

        //Text Watcher, ensure values are input to username and password
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                checkFieldsForEmptyValues();
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        };
    }


    //Checks fields for input and checkbox for login
    public void onLoginClick(View view) {
        try {
            // get user input
            newUser = (CheckBox) findViewById(R.id.newUserCheckBox);
            String username = ((EditText) findViewById(R.id.editTextUsername)).getText().toString();
            String password = ((EditText) findViewById(R.id.editTextPassword)).getText().toString();

            // Login if user/password correct or creates new if checkbox is checked.
            if (!newUser.isChecked()) {
                boolean isAuthenticated = login(username, password);
                if (isAuthenticated) {
                    user = new User(username, password);
                    Toast.makeText(LoginActivity.this, "Successful Login", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(this, DataActivity.class);
                    intent.putExtra("user", user);
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid Login", Toast.LENGTH_LONG).show();
                }
            } else {
                try {
                    List<User> userList = userD.getUsers();
                    boolean found = false;
                    // see if username is already taken
                    if (userList.size() > 0) {
                        for (int i = 0; i < userList.size(); i++) {
                            if (userList.get(i).getUsername().equals(username)) {
                                found = true;
                            }
                        }
                    }
                    // if username is not in the database already
                    if (!found) {
                        userD.insertUser(new User(username, password));
                        Toast.makeText(LoginActivity.this, "Account Created", Toast.LENGTH_LONG).show();
                        user = new User(username, password);
                        Intent intent = new Intent(this, DataActivity.class);
                        intent.putExtra("user", user);
                        startActivity(intent);
                    }
                    // else if username is already taken, notify user
                    else {
                        Toast.makeText(LoginActivity.this, "Username Already In Use", Toast.LENGTH_LONG).show();
                    }

                } catch (Exception e) {
                    Toast.makeText(LoginActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();

                }

            }
        } catch (Exception e) {
            Toast.makeText(LoginActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    //Verify login
    private boolean login(String username, String password) {
        List<User> userList = userD.getUsers();
        for (int i = 0; i < userList.size(); i++) {
            if (userList.get(i).getUsername().equals(username) &&
                    userList.get(i).getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }



    //Disables login button if fields are empty (need 3+ characters)
    private void checkFieldsForEmptyValues() {
        String inputUserName = username.getText().toString();
        String inputPassword = password.getText().toString();
        if((inputUserName.length() > 2) && inputPassword.length() > 2){
            login.setEnabled(true);
        }
        else {
            login.setEnabled(false);
        }
    }

    public void exitClick(View view) {
        finish();
        System.exit(0);
    }
}
