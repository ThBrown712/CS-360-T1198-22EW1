package com.example.weighttrackerapplication_thomasbrown;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddEntry extends AppCompatActivity {

    private EditText enterDate;
    private EditText enterWeight;
    private Button acceptButton;
    private Button cancelButton;
    private TheDatabase WeightDb;
    private WeightData weightData;
    private Weight userWeight;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

            //singleton

            WeightDb = TheDatabase.getInstance(getApplicationContext());
            weightData  = WeightDb.weightD();

            setContentView(R.layout.add_entry_activity);

            enterDate = (EditText) this.findViewById(R.id.editTextDate);
            enterWeight = (EditText) this.findViewById(R.id.deleteRecord_editTextWeight);
            acceptButton = (Button) this.findViewById(R.id.acceptEntryButton);
            cancelButton = (Button) this.findViewById(R.id.cancelButton);

            Intent intent = getIntent();
            user = (User) getIntent().getSerializableExtra("user");

    }


    //Accept button to input new data
    public void acceptEntryButtonClick(View view) throws ParseException {
            DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
            Date date;

            // get date input and parse
            String date_string = enterDate.getText().toString();
            date = formatter.parse(date_string);

            // get weight input
            String weight_string = enterWeight.getText().toString();
            // if weight input is not a parsable double
            if (!isParsableDouble(weight_string)) {
                System.out.println("COULD NOT PARSE DOUBLE!!");
                Toast.makeText(AddEntry.this, "It didn't work!", Toast.LENGTH_LONG).show();
                cancelButtonClick(cancelButton);
            }
            // parse input to double
            double weight = Double.parseDouble(weight_string);

            // make new Weight object
            Weight newWeight = new Weight();
            newWeight.setDate(date);
            newWeight.setWeight(weight);
            newWeight.setUsername(user.getUsername());

            weightData.insertWeight(newWeight);

            finish();
    }



    //cancel and return to data activity
    public void cancelButtonClick(View view) {
        Intent returnIntent = getIntent();
        setResult(Activity.RESULT_CANCELED, returnIntent);
        finish();
    }



    public static boolean isParsableDouble(String input) {
        try {
            Double.parseDouble(input);
            return true;
        } catch (final NumberFormatException e) {
            return false;
        }
    }
}