package com.example.weighttrackerapplication_thomasbrown;


import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.Gravity;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class DataActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1;
    private static final int PERMISSION_READ_STATE = 2;
    private TheDatabase weightDatabase;
    private WeightData weightData;
    private GoalData goalData;
    private User user;
    TableLayout tableLayout;
    TextView goalWeight;
    TableRow emptyRecord;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);
            setContentView(R.layout.data_activity);

            tableLayout = (TableLayout)findViewById(R.id.weightTable);
            goalWeight = (TextView)findViewById(R.id.goalWeightText);

            // singleton
            weightDatabase = TheDatabase.getInstance(getApplicationContext());
            weightData = weightDatabase.weightD();

            // intial empty row
            emptyRecord = (TableRow) findViewById(R.id.emptyData);

            // get User object from login screen
            Intent intent = getIntent();
            user = (User) getIntent().getSerializableExtra("user");

            // refresh the table and target weight textview
            refreshTable();
            refreshGoal();

            // check for granted permissions, ask user for permissions if need be
            checkForAllPermissions();
        }

    @Override
    protected void onResume() {
        super.onResume();
        refreshTable();
        refreshGoal();
        reachedGoalCheck();

    }



        //Refreshes the table
    public void refreshGoal() {
            goalData = weightDatabase.goalD();
            int count = goalData.countGoalEntries(user.getUsername());
            // if there is no goal weight, insert default goal weight of 100lbs
            if (count == 0) {
                Goal defaultGoal = new Goal(100.0, user.getUsername());
                goalData.insertGoal(defaultGoal);
                return;
            }
            else if (count < 0 || count > 1) {
                Toast.makeText(DataActivity.this, "Error with Goal", Toast.LENGTH_LONG).show();

                return;
            }

            count = goalData.countGoalEntries(user.getUsername());

            Goal currentGoal = goalData.getSingleGoalWeight(user.getUsername());
            goalWeight.setText(currentGoal.getGoal() + " lbs");

    }


    public void refreshTable() {

            // remove all but the header from the TableLayout
            cleanTable(tableLayout);
            // get all DailyWeight records of this user
            List<Weight> userWeights = weightData.getUserWeights(user.getUsername());

            // if there are no DailyWeights for this user
            if (userWeights.size() == 0) {

                addEmptyRecordsRow(tableLayout);
            }
            // if there are DailyWeights for this user
            else {

                DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
                TableRow header = (TableRow) findViewById(R.id.headerRow);
                TextView headerDate = (TextView) findViewById(R.id.headerDate);
                TextView headerWeight = (TextView) findViewById(R.id.headerWeight);

                TableLayout.LayoutParams layoutParamsTable = (TableLayout.LayoutParams) header.getLayoutParams();
                // layout parameters for textViews:
                TableRow.LayoutParams layoutParamsRow = (TableRow.LayoutParams) headerDate.getLayoutParams();

                for (int i = 0; i < userWeights.size(); i++) {
                    TableRow row = new TableRow(this);
                    TextView dateTextView = new TextView(this);
                    TextView weightTextView = new TextView(this);


                    row.setLayoutParams(layoutParamsTable);
                    dateTextView.setLayoutParams(layoutParamsRow);
                    weightTextView.setLayoutParams(layoutParamsRow);

                    dateTextView.setWidth(0);
                    dateTextView.setGravity(Gravity.CENTER);
                    dateTextView.setPadding(20, 20, 20, 20);
                    weightTextView.setWidth(0);
                    weightTextView.setGravity(Gravity.CENTER);
                    weightTextView.setPadding(20, 20, 20, 20);

                    // set the value of the date TextView
                    dateTextView.setText(formatter.format(userWeights.get(i).getDate()));
                    // set the value of the weight TextView
                    weightTextView.setText(Double.toString(userWeights.get(i).getWeight()));


                    row.addView(dateTextView);
                    row.addView(weightTextView);

                    // add row to TableLayout
                    tableLayout.addView(row);
                }
            }
    }


    private void cleanTable(TableLayout table) {
            int childCount = table.getChildCount();

            // Remove all rows except the first one
            if (childCount > 1) {
                table.removeViews(1, childCount - 1);
            }
    }

    private void addEmptyRecordsRow(TableLayout table) {
        tableLayout.addView(emptyRecord);
    }

    // Check if user has reached target weight
    private void reachedGoalCheck() {

            List<Weight> userDailyWeights = weightData
                    .getUserWeights(user.getUsername());

            // get most recent weight
            if (userDailyWeights.size() != 0) {
                double currentWeight = userDailyWeights.get(userDailyWeights.size() - 1).getWeight();

                double goalWeight = goalData.getSingleGoalWeight(user.getUsername()).getGoal();

                // if current weight is lower than goal, send congratulating text to user
                if (currentWeight <= goalWeight) {
                    sendSMSToUser();
                }
            }

    }


    public void sendSMSToUser() {
            // if permission active, send text to user
            checkForAllPermissions();
            if (ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS) ==
                    PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(this,
                            Manifest.permission.READ_PHONE_STATE)
                            == PackageManager.PERMISSION_GRANTED) {
                SmsManager smsManager = SmsManager.getDefault();
                TelephonyManager telephonyManager = (TelephonyManager) this.getSystemService(this.TELEPHONY_SERVICE);
                String phoneNum = telephonyManager.getLine1Number();
                if (phoneNum != null) {
                    smsManager.sendTextMessage(phoneNum, null,
                            "Congratulations, you reached your target weight!",
                            null, null);
                }
            }
            else {
                Toast.makeText(DataActivity.this, "Goal Achieved!", Toast.LENGTH_LONG).show();
            }

    }



    public void checkForAllPermissions() {

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
                    != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                            != PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_PHONE_STATE,
                                Manifest.permission.SEND_SMS},
                        PERMISSION_READ_STATE);
            }

    }



    // Callback for add entry button
    public void addEntryButtonClick(View view) {
            // call AddEntry activity
            Intent intent = new Intent(this, AddEntry.class);
            intent.putExtra("user", user);
            startActivity(intent);

    }

    // Callback for entry button
    public void deleteEntryOnClick(View view) {
            // call Delete Entry Activity
            Intent intent = new Intent(this, DeleteEntry.class);
            intent.putExtra("user", user);
            startActivity(intent);

    }

    // Callback for edit record button
    public void editEntryOnClick(View view) {
            // call Update Entry Activity
            Intent intent = new Intent(this, UpdateEntry.class);
            intent.putExtra("user", user);
            startActivity(intent);

    }


    // Callback for edit target weight button
    public void editGoalOnClick(View view) {
        Intent intent = new Intent(this, UpdateGoal.class);
        intent.putExtra("user", user);
        startActivity(intent);

    }


}