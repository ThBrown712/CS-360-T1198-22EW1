package com.example.weighttrackerapplication_thomasbrown;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class UpdateGoal extends AppCompatActivity {

    private TheDatabase weightDb;
    private GoalData goalData;
    User user;
    EditText enterGoal;
    Button saveGoalButton;
    Button cancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_goal_activity);

        // singleton
        weightDb = TheDatabase.getInstance(getApplicationContext());
        goalData = weightDb.goalD();


        enterGoal = (EditText) this.findViewById(R.id.goalWeight_editText);
        saveGoalButton = (Button) this.findViewById(R.id.acceptEntryButton);
        cancelButton = (Button) this.findViewById(R.id.cancelButton);

        // get current user from intent
        Intent intent = getIntent();
        user = (User) intent.getSerializableExtra("user");
    }





    public void saveGoalOnClick(View view) {

            String weight_string = enterGoal.getText().toString();

            // if weight input is not a parsable double, notify user
            if (!isParsableDouble(weight_string)) {
                Toast.makeText(UpdateGoal.this, "Entry Error", Toast.LENGTH_LONG).show();
            }
            // parse input to double
            double weight = Double.parseDouble(weight_string);

            // perform update on database record
            goalData.updateGoal(weight, user.getUsername());

            // end this activity and return to calling activity
            Intent returnableIntent = getIntent();
            setResult(Activity.RESULT_OK, returnableIntent);
            finish();

    }


    public void cancelButtonClick(View view) {
        Intent returnIntent = getIntent();
        setResult(Activity.RESULT_CANCELED, returnIntent);
        finish();
    }

    public static boolean isParsableDouble(String input) {
        try {
            Double.parseDouble(input);
            return true;
        } catch (final NumberFormatException e) {
            return false;
        }
    }
}