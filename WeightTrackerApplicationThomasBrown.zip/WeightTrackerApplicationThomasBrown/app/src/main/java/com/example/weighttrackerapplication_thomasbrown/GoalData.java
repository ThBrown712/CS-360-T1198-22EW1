package com.example.weighttrackerapplication_thomasbrown;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface GoalData {

    //Get goal weight
    @Query("SELECT * FROM goal WHERE username = :username ORDER BY id")
    List<Goal> getAllUserGoalWeights(String username);


    @Query("SELECT * FROM goal WHERE username = :username")
    Goal getSingleGoalWeight(String username);


    @Query("UPDATE goal SET goal = :newGoal WHERE username = :username")
    void updateGoal(double newGoal, String username);


    @Query("SELECT count(*) FROM goal WHERE username = :username")
    int countGoalEntries(String username);

    @Insert(onConflict = OnConflictStrategy.ABORT)
    public void insertGoal(Goal goal);

}